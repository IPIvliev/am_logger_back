<?php

	defined('_JEXEC') or die('Restricted access');
	
	// Include the syndicate functions only once
	require_once (dirname(__FILE__).DS.'helper.php');
	
	
	require_once( JPATH_BASE . DS . 'components' . DS . 'com_community' . DS . 'libraries' . DS . 'core.php');
	include_once( JPATH_BASE . DS . 'components' . DS . 'com_community' . DS . 'libraries' . DS . 'karma.php');
	
	$my =& CFactory::getUser();
	$online =  $my->isOnline();
			
	if($online){
		$inboxModel = CFactory::getModel('inbox');
		$filter = array();
		$filter ['user_id'] = $my->id;		
		$friendModel = & CFactory::getModel ( 'friends' );		
		$config	=& CFactory::getConfig();		
		
		$params->def('unreadCount',	$inboxModel->countUnRead ( $filter ));
		$params->def('pending', count( $friendModel->getPending( $my->id )));
		$params->def('myLink', CRoute::_('index.php?option=com_community&view=profile&userid='.$my->id));
		$params->def('myName', $my->getDisplayName());
		$params->def('myAvatar', $my->getAvatar());
		$params->def('myId', $my->id);
		$params->def('myKarma', CKarma::getKarmaImage($my));
		$params->def('enablephotos', $config->get('enablephotos'));
				
		$cache =& JFactory::getCache('mod_hellome');
		$cache->setCaching($params->get('customCache', 1));
		$callback = array('modHelloMeHelper', 'getHelloMeHTML');		
		$content = $cache->call($callback, $params);
		
		/*
		$hellome = new 	modHelloMeHelper($params);
		$list = $hellome->getHelloMeHTML();	
		require(JModuleHelper::getLayoutPath('mod_hellome'));
		*/
	}
	
	
?>