﻿<?php

	defined('_JEXEC') or die('Restricted access');
	
	class modHelloMeHelper
	{		
		function getHelloMeHTML($params){
			
			$unreadCount = $params->get('unreadCount', 1);
			$pending = $params->get('pending', 1);
			$myLink = $params->get('myLink', 1);
			$myName = $params->get('myName', 1);
			$myAvatar = $params->get('myAvatar', 1);
			$myId = $params->get('myId', 1);
			$myKarma = $params->get('myKarma', 1);
			$enablephotos = $params->get('enablephotos', 1);
                  $enableblog = $params->get('enableblog', 1);
			$show_avatar = $params->get('show_avatar', 1);
			$show_karma = $params->get('show_karma', 1);
				
			$html = "";					
			//<!-- User info -->
			$html .= "<div style='text-align: center; border-bottom: 1px solid #ccc; margin: 4px 0; padding: 0 0 10px;'>";
			    $html .= "<div><a href =".$myLink.">".$myName."</a></div>";			
				if($show_avatar){
					$html .= "<img src=".$myAvatar." alt=".$myName." style='padding: 2px; border: solid 1px #ccc;' />";
				}
				
				$html .= "<div>";			
				if($show_karma){			
					$html .= "<img src=".$myKarma." alt=".JText::_('Karma')." width='103' height='19' style='margin: 5px 0 0;' />";
				}
				$html .= "</div>";
			$html .= "</div>";
	
	        $html .= "<div style='border-bottom: 1px solid #ecebeb; margin: 4px 0; padding: 0 0 10px;'>";
				//<!-- Inbox -->
				$html .= "<div style='background: transparent url(".JURI::base()."modules/mod_hellome/images/icons-16x16.gif) no-repeat 0 -118px; padding: 0 0 0 22px;'>";
					$html .= "<a style='line-height: 18px;;' href='".CRoute::_("index.php?option=com_community&view=inbox")."'>".$unreadCount." ".JText::_('CC NEW MESSAGES')."</a>";
				$html .= "</div>";
	
				//<!-- Friend Request -->
				$html .= "<div style='background: transparent url(".JURI::base()."modules/mod_hellome/images/icons-16x16.gif) no-repeat 0 -180px; padding: 0 0 0 22px;'>";
					$html .= "<a style='line-height: 18px;' href='".CRoute::_("index.php?option=com_community&view=friends&task=pending")."'>".$pending." ".JText::_('CC NEW FRIEND REQUESTS')."</a>";
				$html .= "</div>";
			$html .= "</div>";
			
			$html .= "<div style='border-bottom: 1px solid #ecebeb; margin: 4px 0; padding: 0 0 10px;'>";
				$html .= "<div style='background: transparent url(".JURI::base()."modules/mod_hellome/images/icons-16x16.gif) no-repeat 0 -2px; padding: 0 0 0 22px;'>";
					$html .= "<a style='line-height: 18px;' href='".CRoute::_("index.php?option=com_community&view=friends&userid=".$myId)."'>".JText::_('CC MY FRIENDS')."</a>";
				$html .= "</div>";
	
				$html .= "<div style='background: transparent url(".JURI::base()."modules/mod_hellome/images/icons-16x16.gif) no-repeat 0 -58px; padding: 0 0 0 22px;'>";
					$html .= "<a style='line-height: 18px;' href='".CRoute::_("index.php?option=com_community&view=groups&task=mygroups&userid=".$myId)."'>".JText::_('CC MY GROUPS TITLE')."</a>";
				$html .= "</div>";

		   if($enablephotos) {
					$html .= "<div style='background: transparent url(".JURI::base()."modules/mod_hellome/images/icons-16x16.gif) no-repeat 0 -356px; padding: 0 0 0 22px;'>";
						$html .= "<a style='line-height: 18px;' href='".CRoute::_("index.php?option=com_community&view=photos&task=myphotos&userid=".$myId)."'>".JText::_('CC MY PHOTOS TITLE')."</a>";
					$html .= "</div>";
				}



$html .= "<div style='background: transparent url(".JURI::base()."modules/mod_hellome/images/icons-16x16.gif) no-repeat 0 -356px; padding: 0 0 0 22px;'>";
						$html .= "<a style='line-height: 18px;' href='".CRoute::_("index.php?option=com_seyret&task=uservideoslist&userid=".$myId)."'>".JText::_('CC MY VIDEOS TITLE')."</a>";
					$html .= "</div>";


			$html .= "<div style='background: transparent url(".JURI::base()."modules/mod_hellome/images/icons-16x16.gif) no-repeat 0 -118px; padding: 0 0 0 22px;'>";
				$html .= "<a style='line-height: 18px;'' href='".JRoute::_('http://joomlahelp.org.ua/index.php?option=com_jomcomment&task=mycomments')."'>".JText::_('CC MY COMMENTS')."</a>";
			$html .= "</div>";


			$html .= "</div>";


if($enableblog) {
			$html .= "<div style='background: transparent url(".JURI::base()."modules/mod_hellome/images/icons-16x16.gif) no-repeat 0 -118px; padding: 0 0 0 22px;'>";
				$html .= "<a style='line-height: 18px;'' href='".JRoute::_('index.php?option=com_myblog&task=adminhome')."'>".JText::_('CC ADD BLOG MESSAGE')."</a>";
			$html .= "</div>";
}

			
			$html .= "<div style='background: transparent url(".JURI::base()."modules/mod_hellome/images/icons-16x16.gif) no-repeat 0 -80px; padding: 0 0 0 22px;'>";
				$html .= "<a style='line-height: 18px;'' href='".JRoute::_('index.php?option=com_user&view=login')."'>".JText::_('CC LOG OUT')."</a>";
			$html .= "</div>";
			
			return $html;
		}
	}


?>
